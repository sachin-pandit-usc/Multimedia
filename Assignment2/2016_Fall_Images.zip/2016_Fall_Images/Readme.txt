Example images, which are in the native RGB formats. 
  They are as follows with dimensions and brief description
   image1.rgb -> 352x288 shows a foreman
   image2.rgb -> 352x288 shows a golf playing scene
   image3.rgb -> 352x288 shows a man in swimming pool
   image4.rgb -> 352x288 shows a construction site

Each image is different in the colors, frequency content etc. and should
serve as a good example for playing with subsampling, color space transformations,
quantization, compression etc.